Facebook
========

About
-----

Facebook API client for Python.

Installation
------------

    $ pip install facebook


History
-------

0.0.0
+++++

* Nothing


